Anything associated with podcasts has not been implemented besides that everything works accordingly to the video. The bonus question searcHP has been implemented. For implementing searcHP 2 addtion methods checkTitle and checkChapters has been created in class AudioBook

